/*
 * Description: 
 *     History: yang@haipo.me, 2017/04/24, create
 */

# ifndef _RH_SERVER_H_
# define _RH_SERVER_H_

int init_server(void);

# endif

