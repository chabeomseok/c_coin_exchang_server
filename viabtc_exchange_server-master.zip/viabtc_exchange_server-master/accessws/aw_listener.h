/*
 * Description: 
 *     History: yang@haipo.me, 2016/04/01, create
 */

# ifndef _AW_LISTENER_H_
# define _AW_LISTENER_H_

int init_listener(void);

# endif

